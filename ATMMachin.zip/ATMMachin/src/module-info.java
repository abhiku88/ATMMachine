/**
 * 
 */
/**
 * 
 */
module ATMMachin {
}